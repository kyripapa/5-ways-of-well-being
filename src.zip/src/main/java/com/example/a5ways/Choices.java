package com.example.a5ways;

/**
 * Created by kyripapa on 13/6/2017.
 */

public class Choices {
    int id;
    String date;
    String category;
    String type;
    String chosen;

    public Choices(){   }
    public Choices(int id, String date, String category, String type, String chosen){
        this.id = id;
        this.date = date;
        this.category = category;
        this.type = type;
        this.chosen = chosen;
    }

    public Choices(String date, String category, String type, String chosen){
        this.date = date;
        this.category = category;
        this.type = type;
        this.chosen = chosen;
    }
    public int getID(){
        return this.id;
    }

    public void setID(int id){
        this.id = id;
    }

    public String getDate(){
        return this.date;
    }

    public void setDate(String name){
        this.date = date;
    }

    public String getCategory(){
        return this.category;
    }

    public void setCategory(String category){
        this.category = category;
    }
    public String getType(){
        return this.type;
    }

    public void setType(String type){
        this.type = type;
    }
    public String getChosen(){
        return this.chosen;
    }

    public void setChosen(String chosen){
        this.chosen = chosen;
    }
}